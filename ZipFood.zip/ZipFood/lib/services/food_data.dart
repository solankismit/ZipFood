import 'package:cloud_firestore/cloud_firestore.dart';

class Food {
  int? srno;
  String? recipeName;
  String? translatedRecipeName;
  String? ingredients;
  String? translatedIngredients;
  int? prepTimeInMins;
  int? cookTimeInMins;
  int? totalTimeInMins;
  int? servings;
  String? cuisine;
  String? course;
  String? diet;
  String? instructions;
  String? translatedInstructions;
  String? uRL;

  Food(
      {this.srno,
        this.recipeName,
        this.translatedRecipeName,
        this.ingredients,
        this.translatedIngredients,
        this.prepTimeInMins,
        this.cookTimeInMins,
        this.totalTimeInMins,
        this.servings,
        this.cuisine,
        this.course,
        this.diet,
        this.instructions,
        this.translatedInstructions,
        this.uRL});
}

class FoodService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<Food>> getFoodsByCategory(String category) async {
    List<Food> foods = [];

    final snapshot = await _firestore
        .collection('foods')
        .where('category', isEqualTo: category)
        .get();

    snapshot.docs.forEach((doc) {
      final food = Food(
          srno: doc['srno'],
          recipeName: doc['recipeName'],
          translatedRecipeName : doc[],
          ingredients,
          translatedIngredients,
          prepTimeInMins,
          cookTimeInMins,
          totalTimeInMins,
          servings,
          cuisine,
          course,
          diet,
          instructions,
          translatedInstructions,
          uRL
      );
      foods.add(food);
    });

    return foods;
  }
}

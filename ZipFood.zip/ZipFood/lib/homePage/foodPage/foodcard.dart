import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:zipfood/constants.dart';
import 'package:zipfood/widgets/buttons.dart';

Widget buildCard(
    {String name = "Chai",
    String cuisine = "Indian",
    String cooktime = "3 Minutes",
    String foodtype = "veg",
    required image,
    String id = ""}) {
  return Container(
    margin: EdgeInsets.symmetric(vertical: .5.h),
    child: Card(
      color: Colors.grey[100],
      //it contains item image, name, cuisine,cook time
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: SizedBox(
        height: 18.h,
        width: 100.w,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              width: 4.w,
            ),
            Container(
              height: 11.h,
              width: 25.w,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: AssetImage(image),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(
              width: 4.w,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  name,
                  style: titleStyle.copyWith(
                      color: kPrimaryColor, fontSize: 20.sp),
                ),
                SizedBox(
                  height: 1.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 1.w,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cuisine,
                          style:
                              subtitleStyle.copyWith(color: Color(0xff830F0F)),
                        ),
                        SizedBox(
                          height: .4.h,
                        ),
                        Text(
                          cooktime,
                          style: TextStyle(fontSize: 8.sp),
                        ),
                      ],
                    ),
                    button(
                      // height: 2.0,
                      // width: 1.0,
                      text: 'View Details',
                      onPressed: () {},
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

Widget buildSquareCard({required String name,required String img}) {
  return ElevatedButton(
      onPressed: () {},
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        elevation: 5,
        fixedSize: Size(100,100),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [Image.asset(img), Text(name.toUpperCase(),style: subtitleStyle.copyWith(color: Color(0xffA01111)),)],
      ));
}

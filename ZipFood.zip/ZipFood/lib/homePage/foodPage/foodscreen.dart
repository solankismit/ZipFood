import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sizer/sizer.dart';
import 'package:zipfood/homePage/foodPage/foodcard.dart';
import 'package:zipfood/services/category_data.dart';
import '../../constants.dart';

class FoodScreen extends StatelessWidget {
  final categoryController = Get.put(CategoryController());
   FoodScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          buildAppBar(name: "ZipFood"),
          SingleChildScrollView(
            child: Column(
              children: [
                buildCard(
                    image: "assets/images/chai.jpg",
                    name: 'Recently Ordered',
                    cuisine: 'Chai'),
                // buildSquareCard(),
              ],
            ),
          ),
          Text(
            'Categories',
            style: subtitleStyle.copyWith(
              fontSize: 25.sp,
              fontWeight: FontWeight.bold,
              color: Color(0xffA01111),
            ),
          ),
          Container(
            height: 53.h,
            width: 70.w,
            child: Obx(() => GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 20, mainAxisSpacing: 20),
              itemCount: categoryController.categories.length,
              itemBuilder: (context, index) {
                var nameTxt = categoryController.categories[index].name;
                return buildSquareCard(
                    name: nameTxt, img: "assets/images/chai.jpg");
              },
            ),)
          ),
        ],
      ),
    );
  }
}

Widget buildAppBar(
    {required String name, bool icon = true, color = Colors.white}) {
  return Container(
    margin: EdgeInsets.only(top: 5.h),
    height: 8.h,
    width: 100.w,
    color: color,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        icon
            ? IconButton(
                onPressed: () {
                  // Get.back();
                },
                icon: SvgPicture.asset('assets/icons/heart.svg'))
            : SizedBox(),
        Text(
          name,
          style: titleStyle.copyWith(
            fontSize: 20.sp,
            fontWeight: FontWeight.bold,
            color: Color(0xffA01111),
          ),
        ),
        icon
            ? IconButton(
                onPressed: () {
                  // Get.back();
                },
                icon: SvgPicture.asset('assets/icons/search.svg'))
            : SizedBox(),
      ],
    ),
  );
}

import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:sizer/sizer.dart';
import 'package:zipfood/constants.dart';
import 'package:zipfood/homePage/foodPage/foodscreen.dart';
import 'package:zipfood/homePage/historyPage/historyscreen.dart';
import 'package:zipfood/homePage/homescreen.dart';
import 'package:zipfood/loginPage/authentication.dart';
import 'package:zipfood/loginPage/loginscreen.dart';
import 'package:zipfood/tempage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // await FirebaseAppCheck.instance.activate();
  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (BuildContext context, Orientation orientation, DeviceType deviceType) {
        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Flutter Demo',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          // home: LoginPageWidget(),
          initialRoute: Auth().authuser!=null? MyRoutes.homeRoute:'/',
          unknownRoute: GetPage(name: '/notfound', page: () => LoginPageWidget()),
          getPages: [
            GetPage(name: MyRoutes.loginRoute, page: () => LoginPageWidget()),
            GetPage(name: MyRoutes.homeRoute, page: () => HomeScreen()),
            // GetPage(name: '/second', page: () => Second()),
            // GetPage(
            //     name: '/third',
            //     page: () => Third(),
            //     transition: Transition.zoom
            // ),
          ],
          // home: const MyHomePage(title: 'Flutter Demo Home Page'),
        );
      },
    );
  }
}


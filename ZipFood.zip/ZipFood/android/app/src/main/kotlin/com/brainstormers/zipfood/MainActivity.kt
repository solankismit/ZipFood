package com.brainstormers.zipfood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
